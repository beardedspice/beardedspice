//
//  NewStrategyName.js
//  BeardedSpice
//
//  Created by You on Today's Date.
//  Copyright (c) 2015-2016 GPL v3 http://www.gnu.org/licenses/gpl.html
//

// We put the copyright inside the plist to retain consistent syntax coloring.

// Use a syntax checker to ensure validity. One is provided by nodejs (`node -c filename.js`)
// Normal formatting is supported (can copy/paste with newlines and indentations)

BSStrategy = {
  version: 1,
  displayName: "Subsonic",
  accepts: {
    method: "predicateOnTab",
    format: "%K LIKE[c] 'Subsonic'",
    args: ["title"]
  },

  isPlaying: function() {
    if ((typeof window.frames['playQueue'].localPlayer) === 'object') {
        return window.frames['playQueue'].localPlayer.paused ? 'PAUSED' : 'PLAYING';
    }
    else {
        return window.frames['playQueue'].jwplayer().getState()
    }
  },
  toggle: function() {
    if ((typeof window.frames['playQueue'].localPlayer) === 'object') {
        window.frames['playQueue'].localPlayer.paused ? window.frames['playQueue'].onStart() : window.frames['playQueue'].onStop();
    }
    else {
        window.frames['playQueue'].jwplayer().play()
    }
  },
  previous:  function () { window.frames['playQueue'].onPrevious() },
  next:      function () { window.frames['playQueue'].onNext() },
  pause:     function() {
    if((typeof window.frames['playQueue'].onStop) === 'function') {
        window.frames['playQueue'].onStop();
    } else {
        window.frames['playQueue'].jwplayer().pause(true)
    }
  },
  favorite:  function () { window.frames['playQueue'].onStar(window.frames['playQueue'].getCurrentSongIndex()) },
  /*
  - Return a dictionary of namespaced key/values here.
  All manipulation should be supported in javascript.

  - Namespaced keys currently supported include: track, album, artist, favorited, image (URL)
  */
  trackInfo: function(){
    var playQueue = window.frames['playQueue'].songs[window.frames['playQueue'];
    var ret = playQueue.getCurrentSongIndex()];

    return {
        'title': ret.title,
        'album': ret.album,
        'artist': ret.artist,
        'favorited': ret.starred,
        'image': playQueue.getCurrentSongIndex()].albumUrl.replace('main','coverArt').concat('&size=128'),
    };
  }
}
// The file must have an empty line at the end.
